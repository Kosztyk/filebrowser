package settings

import (
	"os"
	"strconv"
	"strings"

	fberrors "github.com/filebrowser/filebrowser/v2/errors"
	"github.com/filebrowser/filebrowser/v2/rules"
	"github.com/filebrowser/filebrowser/v2/users"
)

// StorageBackend is a settings storage backend.
type StorageBackend interface {
	Get() (*Settings, error)
	Save(*Settings) error
	GetServer() (*Server, error)
	SaveServer(*Server) error
}

// Storage is a settings storage.
type Storage struct {
	back StorageBackend
}

// NewStorage creates a settings storage from a backend.
func NewStorage(back StorageBackend) *Storage {
	return &Storage{back: back}
}

// Get returns the settings for the current instance.
func (s *Storage) Get() (*Settings, error) {
	set, err := s.back.Get()
	if err != nil {
		return nil, err
	}

	if set.UserHomeBasePath == "" {
		set.UserHomeBasePath = DefaultUsersHomeBasePath
	}

	if set.LogoutPage == "" {
		set.LogoutPage = DefaultLogoutPage
	}

	if set.MinimumPasswordLength == 0 {
		set.MinimumPasswordLength = DefaultMinimumPasswordLength
	}

	if set.Tus == (Tus{}) {
		set.Tus = Tus{
			ChunkSize:  DefaultTusChunkSize,
			RetryCount: DefaultTusRetryCount,
		}
	}

	if set.FileMode == 0 {
		set.FileMode = DefaultFileMode
	}

	if set.DirMode == 0 {
		set.DirMode = DefaultDirMode
	}

	if set.ClamAV.URL == "" {
		set.ClamAV.URL = strings.TrimSpace(os.Getenv("CLAMAV_URL"))
	}
	if set.ClamAV.ScanDepth == 0 {
		if depth, err := strconv.Atoi(strings.TrimSpace(os.Getenv("CLAMAV_SCAN_DEPTH"))); err == nil && depth > 0 {
			set.ClamAV.ScanDepth = depth
		}
	}

	if !set.ConvertX.Configured {
		if set.ConvertX.URL == "" {
			set.ConvertX.URL = strings.TrimRight(strings.TrimSpace(firstNonEmptyEnv("FB_CONVERTX_URL", "CONVERTX_URL")), "/")
		}
		if set.ConvertX.APIKey == "" {
			set.ConvertX.APIKey = strings.TrimSpace(firstNonEmptyEnv("FB_CONVERTX_API_KEY", "CONVERTX_API_KEY", "CONVERTX_API_TOKEN"))
		}
		if set.ConvertX.Timeout == "" {
			set.ConvertX.Timeout = strings.TrimSpace(firstNonEmptyEnv("FB_CONVERTX_TIMEOUT", "CONVERTX_TIMEOUT"))
		}
		if enabled := strings.TrimSpace(firstNonEmptyEnv("FB_CONVERTX_ENABLED", "CONVERTX_ENABLED")); enabled != "" {
			if parsed, err := strconv.ParseBool(enabled); err == nil {
				set.ConvertX.Enabled = parsed
			}
		}
	}
	if set.ConvertX.Timeout == "" {
		set.ConvertX.Timeout = "2m"
	}

	if !set.Erugo.Configured {
		if set.Erugo.URL == "" {
			set.Erugo.URL = strings.TrimRight(strings.TrimSpace(firstNonEmptyEnv("FB_ERUGO_URL", "ERUGO_BASE_URL", "ERUGO_URL")), "/")
		}
		if set.Erugo.APIKey == "" {
			set.Erugo.APIKey = strings.TrimSpace(firstNonEmptyEnv("FB_ERUGO_API_KEY", "ERUGO_API_TOKEN", "CONVERTX_INTEGRATION_TOKEN"))
		}
		if set.Erugo.ShareEndpoint == "" {
			set.Erugo.ShareEndpoint = strings.TrimSpace(firstNonEmptyEnv("FB_ERUGO_SHARE_ENDPOINT", "ERUGO_SHARE_ENDPOINT"))
		}
		if set.Erugo.ReverseShareEndpoint == "" {
			set.Erugo.ReverseShareEndpoint = strings.TrimSpace(firstNonEmptyEnv("FB_ERUGO_REVERSE_SHARE_ENDPOINT", "ERUGO_REVERSE_SHARE_ENDPOINT"))
		}
		if set.Erugo.Timeout == "" {
			set.Erugo.Timeout = strings.TrimSpace(firstNonEmptyEnv("FB_ERUGO_TIMEOUT", "ERUGO_TIMEOUT"))
		}
		if set.Erugo.UploadTimeout == "" {
			set.Erugo.UploadTimeout = strings.TrimSpace(firstNonEmptyEnv("FB_ERUGO_UPLOAD_TIMEOUT", "ERUGO_UPLOAD_TIMEOUT"))
		}
		if enabled := strings.TrimSpace(firstNonEmptyEnv("FB_ERUGO_ENABLED", "ERUGO_ENABLED")); enabled != "" {
			if parsed, err := strconv.ParseBool(enabled); err == nil {
				set.Erugo.Enabled = parsed
			}
		}
		if hours := strings.TrimSpace(firstNonEmptyEnv("FB_ERUGO_DEFAULT_EXPIRY_HOURS", "ERUGO_DEFAULT_EXPIRY_HOURS")); hours != "" {
			if parsed, err := strconv.Atoi(hours); err == nil && parsed > 0 {
				set.Erugo.DefaultExpiryHours = parsed
			}
		}
	}
	if set.Erugo.ShareEndpoint == "" {
		set.Erugo.ShareEndpoint = "/api/integrations/convertx/share"
	}
	if set.Erugo.ReverseShareEndpoint == "" {
		set.Erugo.ReverseShareEndpoint = "/api/integrations/filebrowser/reverse-share"
	}
	if set.Erugo.DefaultExpiryHours <= 0 {
		set.Erugo.DefaultExpiryHours = 168
	}
	if set.Erugo.Timeout == "" {
		set.Erugo.Timeout = "2m"
	}
	if set.Erugo.UploadTimeout == "" {
		set.Erugo.UploadTimeout = "2h"
	}

	return set, nil
}

func firstNonEmptyEnv(keys ...string) string {
	for _, key := range keys {
		if value := os.Getenv(key); value != "" {
			return value
		}
	}
	return ""
}

var defaultEvents = []string{
	"save",
	"copy",
	"rename",
	"upload",
	"delete",
}

// Save saves the settings for the current instance.
func (s *Storage) Save(set *Settings) error {
	if len(set.Key) == 0 {
		return fberrors.ErrEmptyKey
	}

	if set.Defaults.Locale == "" {
		set.Defaults.Locale = "en"
	}

	if set.Defaults.Commands == nil {
		set.Defaults.Commands = []string{}
	}

	if set.Defaults.ViewMode == "" {
		set.Defaults.ViewMode = users.MosaicViewMode
	}

	if set.Rules == nil {
		set.Rules = []rules.Rule{}
	}

	if set.Shell == nil {
		set.Shell = []string{}
	}

	if set.Commands == nil {
		set.Commands = map[string][]string{}
	}

	for _, event := range defaultEvents {
		if _, ok := set.Commands["before_"+event]; !ok {
			set.Commands["before_"+event] = []string{}
		}

		if _, ok := set.Commands["after_"+event]; !ok {
			set.Commands["after_"+event] = []string{}
		}
	}

	err := s.back.Save(set)
	if err != nil {
		return err
	}

	return nil
}

// GetServer wraps StorageBackend.GetServer.
func (s *Storage) GetServer() (*Server, error) {
	return s.back.GetServer()
}

// SaveServer wraps StorageBackend.SaveServer and adds some verification.
func (s *Storage) SaveServer(ser *Server) error {
	ser.Clean()
	return s.back.SaveServer(ser)
}

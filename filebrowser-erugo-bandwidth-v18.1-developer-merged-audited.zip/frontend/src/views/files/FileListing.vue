<template>
  <div>
    <header-bar showMenu showLogo>
      <search />
      <title />
      <action
        class="search-button"
        icon="search"
        :label="t('buttons.search')"
        @action="openSearch()"
      />

      <template #actions>
        <template v-if="!isMobile">
          <action
            v-if="headerButtons.share"
            icon="share"
            :label="t('buttons.share')"
            show="share"
          />
          <action
            v-if="headerButtons.reverseShare"
            icon="move_to_inbox"
            :label="t('settings.erugoReverseShare')"
            show="erugo-reverse-share"
          />
          <action
            v-if="headerButtons.rename"
            icon="mode_edit"
            :label="t('buttons.rename')"
            show="rename"
          />
          <action
            v-if="headerButtons.collabora"
            icon="description"
            :label="t('buttons.openWithCollabora')"
            @action="openSelectedWithCollabora"
          />
          <action
            v-if="headerButtons.convert"
            id="convertx-button"
            icon="sync_alt"
            :label="t('buttons.convertTo')"
            @action="openConvertPrompt"
          />
          <action
            v-if="headerButtons.copy"
            id="copy-button"
            icon="content_copy"
            :label="t('buttons.copyFile')"
            show="copy"
          />
          <action
            v-if="headerButtons.move"
            id="move-button"
            icon="forward"
            :label="t('buttons.moveFile')"
            show="move"
          />
          <action
            v-if="headerButtons.delete"
            id="delete-button"
            icon="delete"
            :label="t('buttons.delete')"
            show="delete"
          />
        </template>

        <action
          v-if="headerButtons.shell"
          icon="code"
          :label="t('buttons.shell')"
          @action="layoutStore.toggleShell"
        />
        <action
          :icon="viewIcon"
          :label="t('buttons.switchView')"
          @action="switchView"
        />
        <action
          v-if="headerButtons.download"
          icon="file_download"
          :label="t('buttons.download')"
          @action="download"
          :counter="fileStore.selectedCount"
        />
        <action
          v-if="headerButtons.scan"
          id="scan-button"
          icon="security"
          :label="scanActionLabel"
          @action="scanSelectedWithClamAV"
        />
        <action
          v-if="headerButtons.archiveCreate"
          id="archive-create-button"
          icon="archive"
          :label="archiveActionLabel"
          @action="archiveSelected"
        />
        <action
          v-if="headerButtons.extract"
          id="extract-button"
          icon="folder_zip"
          :label="archiveExtractLabel"
          @action="extractArchive"
        />
        <action
          v-if="headerButtons.upload"
          icon="file_upload"
          id="upload-button"
          :label="t('buttons.upload')"
          @action="uploadFunc"
        />
        <action icon="info" :label="t('buttons.info')" show="info" />
        <action
          icon="check_circle"
          :label="t('buttons.selectMultiple')"
          @action="toggleMultipleSelection"
        />
      </template>
    </header-bar>

    <div
      v-if="isMobile"
      id="file-selection"
      :class="{
        'file-selection-margin-bottom': fileStore.multiple,
      }"
    >
      <span v-if="fileStore.selectedCount > 0">
        {{ t("prompts.filesSelected", fileStore.selectedCount) }}
      </span>
      <action
        v-if="headerButtons.share"
        icon="share"
        :label="t('buttons.share')"
        show="share"
      />
      <action
        v-if="headerButtons.reverseShare"
        icon="move_to_inbox"
        :label="t('settings.erugoReverseShare')"
        show="erugo-reverse-share"
      />
      <action
        v-if="headerButtons.rename"
        icon="mode_edit"
        :label="t('buttons.rename')"
        show="rename"
      />
      <action
        v-if="headerButtons.collabora"
        icon="description"
        :label="t('buttons.openWithCollabora')"
        @action="openSelectedWithCollabora"
      />
      <action
        v-if="headerButtons.convert"
        icon="sync_alt"
        :label="t('buttons.convertTo')"
        @action="openConvertPrompt"
      />
      <action
        v-if="headerButtons.copy"
        icon="content_copy"
        :label="t('buttons.copyFile')"
        show="copy"
      />
      <action
        v-if="headerButtons.move"
        icon="forward"
        :label="t('buttons.moveFile')"
        show="move"
      />
      <action
        v-if="headerButtons.delete"
        icon="delete"
        :label="t('buttons.delete')"
        show="delete"
      />
      <action
        v-if="headerButtons.scan"
        icon="security"
        :label="scanActionLabel"
        @action="scanSelectedWithClamAV"
      />
      <action
        v-if="headerButtons.archiveCreate"
        icon="archive"
        :label="archiveActionLabel"
        @action="archiveSelected"
      />
      <action
        v-if="headerButtons.extract"
        icon="folder_zip"
        :label="archiveExtractLabel"
        @action="extractArchive"
      />
    </div>

    <div v-if="layoutStore.loading">
      <h2 class="message delayed">
        <div class="spinner">
          <div class="bounce1"></div>
          <div class="bounce2"></div>
          <div class="bounce3"></div>
        </div>
        <span>{{ t("files.loading") }}</span>
      </h2>
    </div>
    <template v-else>
      <div
        v-if="
          (fileStore.req?.numDirs ?? 0) + (fileStore.req?.numFiles ?? 0) == 0
        "
      >
        <h2 class="message">
          <i class="material-icons">sentiment_dissatisfied</i>
          <span>{{ t("files.lonely") }}</span>
        </h2>
        <input
          style="display: none"
          type="file"
          id="upload-input"
          @change="uploadInput($event)"
          multiple
        />
        <input
          style="display: none"
          type="file"
          id="upload-folder-input"
          @change="uploadInput($event)"
          webkitdirectory
          multiple
        />
      </div>
      <div
        v-else
        id="listing"
        ref="listing"
        class="file-icons"
        data-clear-on-click="true"
        :class="authStore.user?.viewMode ?? ''"
        @click="handleEmptyAreaClick"
      >
        <div>
          <div class="item header">
            <div>
              <p
                :class="{ active: nameSorted }"
                class="name"
                role="button"
                tabindex="0"
                @click="sort('name')"
                :title="t('files.sortByName')"
                :aria-label="t('files.sortByName')"
              >
                <span>{{ t("files.name") }}</span>
                <i class="material-icons">{{ nameIcon }}</i>
              </p>

              <p
                :class="{ active: sizeSorted }"
                class="size"
                role="button"
                tabindex="0"
                @click="sort('size')"
                :title="t('files.sortBySize')"
                :aria-label="t('files.sortBySize')"
              >
                <span>{{ t("files.size") }}</span>
                <i class="material-icons">{{ sizeIcon }}</i>
              </p>
              <p
                :class="{ active: modifiedSorted }"
                class="modified"
                role="button"
                tabindex="0"
                @click="sort('modified')"
                :title="t('files.sortByLastModified')"
                :aria-label="t('files.sortByLastModified')"
              >
                <span>{{ t("files.lastModified") }}</span>
                <i class="material-icons">{{ modifiedIcon }}</i>
              </p>
            </div>
          </div>
        </div>

        <h2 data-clear-on-click="true" v-if="fileStore.req?.numDirs ?? false">
          {{ t("files.folders") }}
        </h2>
        <div
          v-if="fileStore.req?.numDirs ?? false"
          data-clear-on-click="true"
          @contextmenu="showContextMenu"
        >
          <item
            v-for="item in dirs"
            :key="base64(item.name)"
            v-bind:index="item.index"
            v-bind:name="item.name"
            v-bind:isDir="item.isDir"
            v-bind:url="item.url"
            v-bind:modified="item.modified"
            v-bind:type="item.type"
            v-bind:size="item.size"
            v-bind:path="item.path"
            v-bind:archive="item.archive"
            v-bind:archivePath="item.archivePath"
            v-bind:archiveInnerPath="item.archiveInnerPath"
            v-bind:readOnly="isArchiveView"
          >
          </item>
        </div>

        <h2 data-clear-on-click="true" v-if="fileStore.req?.numFiles ?? false">
          {{ t("files.files") }}
        </h2>
        <div
          v-if="fileStore.req?.numFiles ?? false"
          data-clear-on-click="true"
          @contextmenu="showContextMenu"
        >
          <item
            v-for="item in files"
            :key="base64(item.name)"
            v-bind:index="item.index"
            v-bind:name="item.name"
            v-bind:isDir="item.isDir"
            v-bind:url="item.url"
            v-bind:modified="item.modified"
            v-bind:type="item.type"
            v-bind:size="item.size"
            v-bind:path="item.path"
            v-bind:archive="item.archive"
            v-bind:archivePath="item.archivePath"
            v-bind:archiveInnerPath="item.archiveInnerPath"
            v-bind:readOnly="isArchiveView"
          >
          </item>
        </div>
        <context-menu
          :show="isContextMenuVisible"
          :pos="contextMenuPos"
          @hide="hideContextMenu"
        >
          <action
            v-if="headerButtons.share"
            icon="share"
            :label="t('buttons.share')"
            show="share"
          />
          <action
            v-if="headerButtons.rename"
            icon="mode_edit"
            :label="t('buttons.rename')"
            show="rename"
          />
          <action
            v-if="headerButtons.collabora"
            icon="description"
            :label="t('buttons.openWithCollabora')"
            @action="openSelectedWithCollabora"
          />
          <action
            v-if="headerButtons.convert"
            id="context-convertx-button"
            icon="sync_alt"
            :label="t('buttons.convertTo')"
            @action="openConvertPrompt"
          />
          <action
            v-if="headerButtons.copy"
            id="copy-button"
            icon="content_copy"
            :label="t('buttons.copyFile')"
            show="copy"
          />
          <action
            v-if="headerButtons.move"
            id="move-button"
            icon="forward"
            :label="t('buttons.moveFile')"
            show="move"
          />
          <action
            v-if="headerButtons.delete"
            id="delete-button"
            icon="delete"
            :label="t('buttons.delete')"
            show="delete"
          />
          <action
            v-if="headerButtons.download"
            icon="file_download"
            :label="t('buttons.download')"
            @action="download"
            :counter="fileStore.selectedCount"
          />
          <action
            v-if="headerButtons.scan"
            id="context-scan-button"
            icon="security"
            :label="scanActionLabel"
            @action="scanSelectedWithClamAV"
          />
          <action
            v-if="headerButtons.archiveCreate"
            id="context-archive-create-button"
            icon="archive"
            :label="archiveActionLabel"
            @action="archiveSelected"
          />
          <action
            v-if="headerButtons.extract"
            id="context-extract-button"
            icon="folder_zip"
            :label="archiveExtractLabel"
            @action="extractArchive"
          />
          <action icon="info" :label="t('buttons.info')" show="info" />
        </context-menu>

        <input
          style="display: none"
          type="file"
          id="upload-input"
          @change="uploadInput($event)"
          multiple
        />
        <input
          style="display: none"
          type="file"
          id="upload-folder-input"
          @change="uploadInput($event)"
          webkitdirectory
          multiple
        />

        <div :class="{ active: fileStore.multiple }" id="multiple-selection">
          <p>{{ t("files.multipleSelectionEnabled") }}</p>
          <div
            @click="() => (fileStore.multiple = false)"
            tabindex="0"
            role="button"
            :title="t('buttons.clear')"
            :aria-label="t('buttons.clear')"
            class="action"
          >
            <i class="material-icons">clear</i>
          </div>
        </div>
      </div>
    </template>
  </div>
</template>

<script setup lang="ts">
import { useAuthStore } from "@/stores/auth";
import { useClipboardStore } from "@/stores/clipboard";
import { useFileStore } from "@/stores/file";
import { useLayoutStore } from "@/stores/layout";

import { collabora, users, files as api, share as shareApi } from "@/api";
import { collaboraEnabled, enableExec } from "@/utils/constants";
import * as upload from "@/utils/upload";
import buttons from "@/utils/buttons";
import css from "@/utils/css";
import { throttle } from "lodash-es";
import { Base64 } from "js-base64";

import HeaderBar from "@/components/header/HeaderBar.vue";
import Action from "@/components/header/Action.vue";
import Search from "@/components/Search.vue";
import Item from "@/components/files/ListingItem.vue";
import ContextMenu from "@/components/ContextMenu.vue";
import {
  computed,
  inject,
  nextTick,
  onBeforeUnmount,
  onMounted,
  ref,
  watch,
} from "vue";
import { useRoute, useRouter, onBeforeRouteUpdate } from "vue-router";
import { useI18n } from "vue-i18n";
import { storeToRefs } from "pinia";
import { removePrefix } from "@/api/utils";

const showLimit = ref<number>(50);
const columnWidth = ref<number>(280);
const dragCounter = ref<number>(0);
const width = ref<number>(window.innerWidth);
const itemWeight = ref<number>(0);
const isContextMenuVisible = ref<boolean>(false);
const contextMenuPos = ref<{ x: number; y: number }>({ x: 0, y: 0 });
const erugoShareEnabled = ref<boolean>(false);

const $showError = inject<IToastError>("$showError")!;
const $showSuccess = inject<IToastSuccess>("$showSuccess")!;

const clipboardStore = useClipboardStore();
const authStore = useAuthStore();
const fileStore = useFileStore();
const layoutStore = useLayoutStore();

const { req } = storeToRefs(fileStore);

const route = useRoute();
const router = useRouter();
onBeforeRouteUpdate(() => {
  hideContextMenu();
});

const { t } = useI18n();

const listing = ref<HTMLElement | null>(null);

const nameSorted = computed(() =>
  fileStore.req ? fileStore.req.sorting.by === "name" : false
);

const sizeSorted = computed(() =>
  fileStore.req ? fileStore.req.sorting.by === "size" : false
);

const modifiedSorted = computed(() =>
  fileStore.req ? fileStore.req.sorting.by === "modified" : false
);

const ascOrdered = computed(() =>
  fileStore.req ? fileStore.req.sorting.asc : false
);

const dirs = computed(() => items.value.dirs.slice(0, showLimit.value));

const items = computed(() => {
  const dirs: any[] = [];
  const files: any[] = [];

  fileStore.req?.items.forEach((item) => {
    if (item.isDir) {
      dirs.push(item);
    } else {
      files.push(item);
    }
  });

  return { dirs, files };
});

const files = computed((): Resource[] => {
  let _showLimit = showLimit.value - items.value.dirs.length;

  if (_showLimit < 0) _showLimit = 0;

  return items.value.files.slice(0, _showLimit);
});

const nameIcon = computed(() => {
  if (nameSorted.value && !ascOrdered.value) {
    return "arrow_upward";
  }

  return "arrow_downward";
});

const sizeIcon = computed(() => {
  if (sizeSorted.value && ascOrdered.value) {
    return "arrow_downward";
  }

  return "arrow_upward";
});

const modifiedIcon = computed(() => {
  if (modifiedSorted.value && ascOrdered.value) {
    return "arrow_downward";
  }

  return "arrow_upward";
});

const isArchiveView = computed(() => Boolean(fileStore.req?.archivePath));

const viewIcon = computed(() => {
  const icons = {
    list: "view_module",
    mosaic: "grid_view",
    "mosaic gallery": "view_list",
  };
  return authStore.user === null
    ? icons["list"]
    : icons[authStore.user.viewMode];
});

const selectedItem = computed<ResourceItem | null>(() =>
  fileStore.selectedCount === 1 && fileStore.req
    ? fileStore.req.items[fileStore.selected[0]]
    : null
);

const selectedItems = computed<ResourceItem[]>(() => {
  if (!fileStore.req) return [];

  return fileStore.selected
    .map((index) => fileStore.req?.items[index])
    .filter((item): item is ResourceItem => !!item);
});

const selectedResource = selectedItem;

const canOpenSelectedWithCollabora = computed(() => {
  const item = selectedResource.value;

  return !!(
    collaboraEnabled &&
    !isArchiveView.value &&
    item &&
    !item.archive &&
    !item.isDir &&
    authStore.user?.perm.download &&
    collabora.isSupportedExtension(item.extension)
  );
});

const canConvertSelectedWithConvertX = computed(() => {
  const item = selectedResource.value;

  // Keep the UI action visible when the user can read the source file and
  // create the converted output. The backend still enforces ConvertX being
  // enabled/configured and returns a clear error if it is not. This avoids
  // hiding the button because the static boot config was generated before
  // the admin enabled ConvertX in Settings.
  return !!(
    !isArchiveView.value &&
    item &&
    !item.archive &&
    !item.isDir &&
    item.extension &&
    authStore.user?.perm.download &&
    authStore.user?.perm.create
  );
});

const isSelectedArchiveFile = computed(
  () =>
    !isArchiveView.value &&
    fileStore.selectedCount === 1 &&
    selectedItem.value?.type === "archive"
);

const archiveExtractLabel = computed(() => {
  if (isSelectedArchiveFile.value) {
    return "Extract this archive";
  }

  if (isArchiveView.value) {
    if (selectedItem.value) {
      return selectedItem.value.isDir
        ? "Extract this folder"
        : "Extract this file";
    }

    const currentInner = fileStore.req?.archiveInnerPath || "/";
    return currentInner === "/" ? "Extract archive" : "Extract current folder";
  }

  return "Extract archive";
});

const scanActionLabel = computed(() => {
  if (fileStore.selectedCount > 1) {
    return t("buttons.scanSelected");
  }

  return selectedItem.value?.isDir
    ? t("buttons.scanThisFolder")
    : t("buttons.scanThisFile");
});

const archiveActionLabel = computed(() => {
  if (fileStore.selectedCount > 1) {
    return t("buttons.archiveSelected");
  }

  return selectedItem.value?.isDir
    ? t("buttons.archiveThisFolder")
    : t("buttons.archiveThisFile");
});

const headerButtons = computed(() => {
  const selected = selectedItem.value;

  return {
    upload: !isArchiveView.value && authStore.user?.perm.create,
    download:
      authStore.user?.perm.download &&
      (!isArchiveView.value || (selected !== null && !selected.isDir)),
    extract:
      authStore.user?.perm.create &&
      ((isArchiveView.value && fileStore.selectedCount <= 1) ||
        isSelectedArchiveFile.value),
    scan:
      !isArchiveView.value &&
      fileStore.selectedCount > 0 &&
      authStore.user?.perm.download,
    archiveCreate:
      !isArchiveView.value &&
      fileStore.selectedCount > 0 &&
      authStore.user?.perm.download &&
      authStore.user?.perm.create,
    shell: !isArchiveView.value && authStore.user?.perm.execute && enableExec,
    delete:
      !isArchiveView.value &&
      fileStore.selectedCount > 0 &&
      authStore.user?.perm.delete,
    rename:
      !isArchiveView.value &&
      fileStore.selectedCount === 1 &&
      authStore.user?.perm.rename,
    share:
      !isArchiveView.value &&
      fileStore.selectedCount === 1 &&
      authStore.user?.perm.share &&
      authStore.user?.perm.download,
    reverseShare:
      !isArchiveView.value &&
      erugoShareEnabled.value &&
      authStore.user?.perm.share,
    collabora: canOpenSelectedWithCollabora.value,
    convert: canConvertSelectedWithConvertX.value,
    move:
      !isArchiveView.value &&
      fileStore.selectedCount > 0 &&
      authStore.user?.perm.rename,
    copy:
      !isArchiveView.value &&
      fileStore.selectedCount > 0 &&
      authStore.user?.perm.create,
  };
});

const isMobile = computed(() => {
  return width.value <= 736;
});

watch(req, () => {
  // Reset the show value
  showLimit.value = 50;

  nextTick(() => {
    // Ensures that the listing is displayed
    // How much every listing item affects the window height
    setItemWeight();

    // Scroll to the item opened previously
    if (!revealPreviousItem()) {
      // Fill and fit the window with listing items
      fillWindow(true);
    }
  });
});

const loadErugoCapabilities = async () => {
  try {
    const config = await shareApi.config();
    erugoShareEnabled.value =
      config.backend === "erugo" &&
      config.enabled === true &&
      config.reverseShare === true;
  } catch {
    erugoShareEnabled.value = false;
  }
};

onMounted(() => {
  void loadErugoCapabilities();

  // Check the columns size for the first time.
  columnsResize();

  // How much every listing item affects the window height
  setItemWeight();

  // Scroll to the item opened previously
  if (!revealPreviousItem()) {
    // Fill and fit the window with listing items
    fillWindow(true);
  }

  // Add the needed event listeners to the window and document.
  window.addEventListener("keydown", keyEvent);
  window.addEventListener("scroll", scrollEvent);
  window.addEventListener("resize", windowsResize);

  if (authStore.user?.perm.create && !isArchiveView.value) {
    addDropListeners();
  }
});

onBeforeUnmount(() => {
  // Remove event listeners before destroying this page.
  window.removeEventListener("keydown", keyEvent);
  window.removeEventListener("scroll", scrollEvent);
  window.removeEventListener("resize", windowsResize);

  removeDropListeners();
});

const base64 = (name: string) => Base64.encodeURI(name);

const keyEvent = (event: KeyboardEvent) => {
  // No prompts are shown
  if (layoutStore.currentPrompt !== null) {
    return;
  }

  if (event.key === "Escape") {
    // Reset files selection.
    fileStore.selected = [];
  }

  if (isArchiveView.value) {
    return;
  }

  if (event.key === "Delete") {
    if (!authStore.user?.perm.delete || fileStore.selectedCount == 0) return;

    // Show delete prompt.
    layoutStore.showHover("delete");
  }

  if (event.key === "F2") {
    if (!authStore.user?.perm.rename || fileStore.selectedCount !== 1) return;

    // Show rename prompt.
    layoutStore.showHover("rename");
  }

  // Ctrl is pressed
  if (!event.ctrlKey && !event.metaKey) {
    return;
  }

  switch (event.key) {
    case "f":
    case "F":
      if (event.shiftKey) {
        event.preventDefault();
        layoutStore.showHover("search");
      }
      break;
    case "c":
    case "x":
      copyCut(event);
      break;
    case "v":
      paste(event);
      break;
    case "a":
      event.preventDefault();
      for (const file of items.value.files) {
        if (fileStore.selected.indexOf(file.index) === -1) {
          fileStore.selected.push(file.index);
        }
      }
      for (const dir of items.value.dirs) {
        if (fileStore.selected.indexOf(dir.index) === -1) {
          fileStore.selected.push(dir.index);
        }
      }
      break;
    case "s":
      event.preventDefault();
      document.getElementById("download-button")?.click();
      break;
  }
};

const preventDefault = (event: Event) => {
  // Wrapper around prevent default.
  event.preventDefault();
};
const addDropListeners = () => {
  document.addEventListener("dragover", preventDefault);
  document.addEventListener("dragenter", dragEnter);
  document.addEventListener("dragleave", dragLeave);
  document.addEventListener("drop", drop);
};

const removeDropListeners = () => {
  document.removeEventListener("dragover", preventDefault);
  document.removeEventListener("dragenter", dragEnter);
  document.removeEventListener("dragleave", dragLeave);
  document.removeEventListener("drop", drop);
};

watch(isArchiveView, (archiveView) => {
  if (!authStore.user?.perm.create) return;
  if (archiveView) {
    removeDropListeners();
  } else {
    addDropListeners();
  }
});

const copyCut = (event: Event | KeyboardEvent): void => {
  if ((event.target as HTMLElement).tagName?.toLowerCase() === "input") return;

  if (fileStore.req === null) return;

  const items = [];

  for (const i of fileStore.selected) {
    items.push({
      from: fileStore.req.items[i].url,
      name: fileStore.req.items[i].name,
      size: fileStore.req.items[i].size,
      isDir: fileStore.req.items[i].isDir,
      modified: fileStore.req.items[i].modified,
    });
  }

  if (items.length === 0) {
    return;
  }

  clipboardStore.$patch({
    key: (event as KeyboardEvent).key,
    items,
    path: route.path,
  });
};

const paste = async (event: Event) => {
  if ((event.target as HTMLElement).tagName?.toLowerCase() === "input") return;

  // TODO router location should it be
  const items: any[] = [];

  for (const item of clipboardStore.items) {
    const from = item.from.endsWith("/") ? item.from.slice(0, -1) : item.from;
    const to = route.path + encodeURIComponent(item.name);
    items.push({
      from,
      to,
      name: item.name,
      size: item.size,
      isDir: item.isDir,
      modified: item.modified,
      overwrite: false,
      rename: clipboardStore.path == route.path,
    });
  }

  if (items.length === 0) {
    return;
  }

  const preselect = removePrefix(route.path) + items[0].name;

  let action = (overwrite?: boolean, rename?: boolean) => {
    api
      .copy(items, overwrite, rename)
      .then(() => {
        fileStore.preselect = preselect;
        fileStore.reload = true;
      })
      .catch($showError);
  };

  if (clipboardStore.key === "x") {
    action = (overwrite, rename) => {
      api
        .move(items, overwrite, rename)
        .then(() => {
          clipboardStore.resetClipboard();
          fileStore.preselect = preselect;
          fileStore.reload = true;
        })
        .catch($showError);
    };
  }

  const path = route.path.endsWith("/") ? route.path : route.path + "/";
  const conflict = await upload.checkConflict(items, path, true);

  if (conflict.length > 0) {
    layoutStore.showHover({
      prompt: "resolve-conflict",
      props: {
        conflict: conflict,
      },
      confirm: (event: Event, result: Array<ConflictingResource>) => {
        event.preventDefault();
        layoutStore.closeHovers();
        for (let i = result.length - 1; i >= 0; i--) {
          const item = result[i];
          if (item.checked.length == 2) {
            items[item.index].rename = true;
          } else if (item.checked.length == 1 && item.checked[0] == "origin") {
            items[item.index].overwrite = true;
          } else {
            items.splice(item.index, 1);
          }
        }
        if (items.length > 0) {
          action();
        }
      },
    });

    return;
  }

  action(false, false);
};

const columnsResize = () => {
  // Update the columns size based on the window width.
  const items_ = css(["#listing.mosaic .item", ".mosaic#listing .item"]);
  if (items_ === null) return;

  let columns = Math.floor(
    (document.querySelector("main")?.offsetWidth ?? 0) / columnWidth.value
  );
  if (columns === 0) columns = 1;
  items_.style.width = `calc(${100 / columns}% - 1em)`;
};

const scrollEvent = throttle(() => {
  const totalItems =
    (fileStore.req?.numDirs ?? 0) + (fileStore.req?.numFiles ?? 0);

  // All items are displayed
  if (showLimit.value >= totalItems) return;

  const currentPos = window.innerHeight + window.scrollY;

  // Trigger at the 75% of the window height
  const triggerPos = document.body.offsetHeight - window.innerHeight * 0.25;

  if (currentPos > triggerPos) {
    // Quantity of items needed to fill 2x of the window height
    const showQuantity = Math.ceil((window.innerHeight * 2) / itemWeight.value);

    // Increase the number of displayed items
    showLimit.value += showQuantity;
  }
}, 100);

const dragEnter = () => {
  dragCounter.value++;

  // When the user starts dragging an item, put every
  // file on the listing with 50% opacity.
  const items = document.getElementsByClassName("item");

  Array.from(items).forEach((file: Element) => {
    (file as HTMLElement).style.opacity = "0.5";
  });
};

const dragLeave = () => {
  dragCounter.value--;

  if (dragCounter.value == 0) {
    resetOpacity();
  }
};

const drop = async (event: DragEvent) => {
  event.preventDefault();
  if (isArchiveView.value) return;
  dragCounter.value = 0;
  resetOpacity();

  const dt = event.dataTransfer;
  let el: HTMLElement | null = event.target as HTMLElement;

  if (fileStore.req === null || dt === null || dt.files.length <= 0) return;

  for (let i = 0; i < 5; i++) {
    if (el !== null && !el.classList.contains("item")) {
      el = el.parentElement;
    }
  }

  const files: UploadList = (await upload.scanFiles(dt)) as UploadList;
  let path = route.path.endsWith("/") ? route.path : route.path + "/";

  if (
    el !== null &&
    el.classList.contains("item") &&
    el.dataset.dir === "true"
  ) {
    // Get url from ListingItem instance
    // TODO: Don't know what is happening here
    path = el.__vue__.url;

    try {
      (await api.fetch(path)).items;
    } catch (error: any) {
      $showError(error);
      return;
    }
  }

  // Checking the destination hits the server, so show it is working rather
  // than leaving the action looking inert until the upload starts.
  buttons.loading("upload");
  const conflict = await upload.checkConflict(files, path);

  const preselect = removePrefix(path) + (files[0].fullPath || files[0].name);

  if (conflict.length > 0) {
    buttons.done("upload");
    layoutStore.showHover({
      prompt: "resolve-conflict",
      props: {
        conflict: conflict,
        isUploadAction: true,
      },
      confirm: (event: Event, result: Array<ConflictingResource>) => {
        event.preventDefault();
        layoutStore.closeHovers();
        for (let i = result.length - 1; i >= 0; i--) {
          const item = result[i];
          if (item.checked.length == 2) {
            continue;
          } else if (item.checked.length == 1 && item.checked[0] == "origin") {
            files[item.index].overwrite = true;
          } else {
            files.splice(item.index, 1);
          }
        }
        if (files.length > 0) {
          upload.handleFiles(files, path);
          fileStore.preselect = preselect;
        }
      },
    });

    return;
  }

  upload.handleFiles(files, path);
  fileStore.preselect = preselect;
};

const uploadInput = async (event: Event) => {
  if (isArchiveView.value) return;
  const files = (event.currentTarget as HTMLInputElement)?.files;
  if (files === null) return;

  const folder_upload = !!files[0].webkitRelativePath;

  const uploadFiles: UploadList = [];
  for (let i = 0; i < files.length; i++) {
    const file = files[i];
    const fullPath = folder_upload ? file.webkitRelativePath : undefined;
    uploadFiles.push({
      file,
      name: file.name,
      size: file.size,
      isDir: false,
      fullPath,
    });
  }

  const path = route.path.endsWith("/") ? route.path : route.path + "/";

  // Checking the destination hits the server, so show it is working rather
  // than leaving the action looking inert until the upload starts.
  buttons.loading("upload");
  const conflict = await upload.checkConflict(uploadFiles, path);

  if (conflict.length > 0) {
    buttons.done("upload");
    layoutStore.showHover({
      prompt: "resolve-conflict",
      props: {
        conflict: conflict,
        isUploadAction: true,
      },
      confirm: (event: Event, result: Array<ConflictingResource>) => {
        event.preventDefault();
        layoutStore.closeHovers();
        for (let i = result.length - 1; i >= 0; i--) {
          const item = result[i];
          if (item.checked.length == 2) {
            continue;
          } else if (item.checked.length == 1 && item.checked[0] == "origin") {
            uploadFiles[item.index].overwrite = true;
          } else {
            uploadFiles.splice(item.index, 1);
          }
        }
        if (uploadFiles.length > 0) {
          upload.handleFiles(uploadFiles, path);
        }
      },
    });

    return;
  }

  upload.handleFiles(uploadFiles, path);
};

const resetOpacity = () => {
  const items = document.getElementsByClassName("item");

  Array.from(items).forEach((file: Element) => {
    (file as HTMLElement).style.opacity = "1";
  });
};

const sort = async (by: string) => {
  let asc = false;

  if (by === "name") {
    if (nameIcon.value === "arrow_upward") {
      asc = true;
    }
  } else if (by === "size") {
    if (sizeIcon.value === "arrow_upward") {
      asc = true;
    }
  } else if (by === "modified") {
    if (modifiedIcon.value === "arrow_upward") {
      asc = true;
    }
  }

  try {
    if (authStore.user?.id) {
      await users.update({ id: authStore.user?.id, sorting: { by, asc } }, [
        "sorting",
      ]);
    }
  } catch (e: any) {
    $showError(e);
  }

  fileStore.reload = true;
};

const openSearch = () => {
  layoutStore.showHover("search");
};

const toggleMultipleSelection = () => {
  fileStore.toggleMultiple();
  layoutStore.closeHovers();
};

const windowsResize = throttle(() => {
  columnsResize();
  width.value = window.innerWidth;

  // Listing element is not displayed
  if (listing.value == null) return;

  // How much every listing item affects the window height
  setItemWeight();

  // Fill but not fit the window
  fillWindow();
}, 100);

const openSelectedWithCollabora = () => {
  const item = selectedResource.value;
  if (!item) return;

  router.push({ path: item.url, query: { office: "true" } });
};

const download = () => {
  if (fileStore.req === null) return;

  if (isArchiveView.value) {
    if (fileStore.selectedCount !== 1) return;
    const selected = fileStore.req.items[fileStore.selected[0]];
    if (selected.isDir) return;
    window.open(api.getDownloadURL(selected, false));
    return;
  }

  if (
    fileStore.selectedCount === 1 &&
    !fileStore.req.items[fileStore.selected[0]].isDir
  ) {
    api.download(null, fileStore.req.items[fileStore.selected[0]].url);
    return;
  }

  layoutStore.showHover({
    prompt: "download",
    confirm: (format: any) => {
      layoutStore.closeHovers();

      const files = [];

      if (fileStore.selectedCount > 0 && fileStore.req !== null) {
        for (const i of fileStore.selected) {
          files.push(fileStore.req.items[i].url);
        }
      } else {
        files.push(route.path);
      }

      api.download(format, ...files);
    },
  });
};

const flattenConvertXTargets = (targets: Record<string, string[]>) => {
  const options: Array<{ key: string; converter: string; convertTo: string }> =
    [];
  for (const [converter, formats] of Object.entries(targets || {})) {
    for (const convertTo of formats || []) {
      options.push({
        key: `${converter}:${convertTo}`,
        converter,
        convertTo,
      });
    }
  }
  return options.sort((a, b) =>
    `${a.convertTo}:${a.converter}`.localeCompare(
      `${b.convertTo}:${b.converter}`
    )
  );
};

const openConvertPrompt = async () => {
  const item = selectedResource.value;
  if (!item) return;

  layoutStore.loading = true;
  try {
    const targets = await api.getConvertXTargets(item);
    const options = flattenConvertXTargets(targets.targets);
    if (options.length === 0) {
      $showError(t("files.convertNoTargets"), false);
      return;
    }

    layoutStore.showHover({
      prompt: "convert",
      props: {
        file: item,
        options,
      },
      confirm: async (selection: api.ConvertXSelection) => {
        layoutStore.closeHovers();
        layoutStore.loading = true;
        try {
          const result = await api.convertWithConvertX(item, selection);
          $showSuccess(
            t("files.converted", { destination: result.destination })
          );
          fileStore.preselect = result.destination;
          fileStore.reload = true;
        } catch (e: any) {
          $showError(e, false);
        } finally {
          layoutStore.loading = false;
        }
      },
    });
  } catch (e: any) {
    $showError(e, false);
  } finally {
    layoutStore.loading = false;
  }
};

const scanSelectedWithClamAV = async () => {
  const items = selectedItems.value;
  if (items.length === 0) return;

  layoutStore.loading = true;
  try {
    let scanned = 0;
    for (const item of items) {
      const result = await api.scanWithClamAV(item);
      scanned += result.scanned || 0;
      if (result.infected) {
        $showError(result.message, false);
        return;
      }
    }

    if (items.length === 1) {
      $showSuccess(t("files.scanClean", { count: scanned }));
    } else {
      $showSuccess(t("files.scanCleanMultiple", { count: scanned }));
    }
  } catch (e: any) {
    $showError(e, false);
  } finally {
    layoutStore.loading = false;
  }
};

const archiveSelected = async () => {
  const items = selectedItems.value;
  if (items.length === 0) return;

  layoutStore.loading = true;
  try {
    const result = await api.createArchive(items);
    $showSuccess(
      t("files.archiveCreated", { destination: result.destination })
    );
    fileStore.preselect = result.destination;
    fileStore.reload = true;
  } catch (e: any) {
    $showError(e);
  } finally {
    layoutStore.loading = false;
  }
};

const extractArchive = async () => {
  const item = selectedItem.value;
  let archivePath = "";
  let innerPath = "/";
  let successMessage = "";

  if (isArchiveView.value && fileStore.req?.archivePath) {
    archivePath = fileStore.req.archivePath;
    innerPath = item?.archiveInnerPath || fileStore.req.archiveInnerPath || "/";

    if (item) {
      successMessage = item.isDir ? "Folder extracted to" : "File extracted to";
    } else {
      successMessage =
        innerPath === "/" ? "Archive extracted to" : "Folder extracted to";
    }
  } else if (isSelectedArchiveFile.value && item?.url) {
    archivePath = item.url;
    innerPath = "/";
    successMessage = "Archive extracted to";
  } else {
    return;
  }

  try {
    layoutStore.loading = true;
    const result = await api.extractArchive(archivePath, innerPath);
    $showSuccess(`${successMessage} ${result.destination}`);
    router.push({ path: `/files${result.destination}` });
  } catch (e: any) {
    $showError(e);
  } finally {
    layoutStore.loading = false;
  }
};

const switchView = async () => {
  layoutStore.closeHovers();

  const modes = {
    list: "mosaic",
    mosaic: "mosaic gallery",
    "mosaic gallery": "list",
  };

  const data = {
    id: authStore.user?.id,
    viewMode: (modes[authStore.user?.viewMode ?? "list"] ||
      "list") as ViewModeType,
  };

  users.update(data, ["viewMode"]).catch($showError);

  authStore.updateUser(data);

  setItemWeight();
  fillWindow();
};

const uploadFunc = () => {
  if (
    typeof window.DataTransferItem !== "undefined" &&
    typeof DataTransferItem.prototype.webkitGetAsEntry !== "undefined"
  ) {
    layoutStore.showHover("upload");
  } else {
    document.getElementById("upload-input")?.click();
  }
};

const setItemWeight = () => {
  // Listing element is not displayed
  if (listing.value === null || fileStore.req === null) return;

  let itemQuantity = fileStore.req.numDirs + fileStore.req.numFiles;
  if (itemQuantity > showLimit.value) itemQuantity = showLimit.value;

  // How much every listing item affects the window height
  itemWeight.value = listing.value.offsetHeight / itemQuantity;
};

const fillWindow = (fit = false) => {
  if (fileStore.req === null) return;

  const totalItems = fileStore.req.numDirs + fileStore.req.numFiles;

  // More items are displayed than the total
  if (showLimit.value >= totalItems && !fit) return;

  const windowHeight = window.innerHeight;

  // Quantity of items needed to fill 2x of the window height
  const showQuantity = Math.ceil(
    (windowHeight + windowHeight * 2) / itemWeight.value
  );

  // Less items to display than current
  if (showLimit.value > showQuantity && !fit) return;

  // Set the number of displayed items
  showLimit.value = showQuantity > totalItems ? totalItems : showQuantity;
};

const revealPreviousItem = () => {
  if (!fileStore.req || !fileStore.oldReq) return;

  const index = fileStore.selected[0];
  if (index === undefined) return;

  showLimit.value =
    index + Math.ceil((window.innerHeight * 2) / itemWeight.value);

  nextTick(() => {
    const items = document.querySelectorAll("#listing .item");
    items[index].scrollIntoView({ block: "center" });
  });

  return true;
};

const showContextMenu = (event: MouseEvent) => {
  event.preventDefault();
  isContextMenuVisible.value = true;
  contextMenuPos.value = {
    x: event.clientX + 8,
    y: event.clientY + 8,
  };
};

const hideContextMenu = () => {
  isContextMenuVisible.value = false;
};

const handleEmptyAreaClick = (e: MouseEvent) => {
  const target = e.target;
  if (!(target instanceof HTMLElement)) return;

  if (target.dataset.clearOnClick === "true") {
    fileStore.selected = [];
  }
};
</script>
<style scoped>
#listing {
  min-height: calc(100vh - 8rem);
}

.file-selection-margin-bottom {
  margin-bottom: 3.5rem;
}
</style>
